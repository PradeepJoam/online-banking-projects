-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 10, 2017 at 07:18 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(30) character set latin1 collate latin1_general_cs default NULL,
  `name` varchar(50) default NULL,
  `gender` varchar(20) default NULL,
  `mobile` varchar(12) default NULL,
  `address` varchar(5000) default NULL,
  `country` varchar(50) default NULL,
  `dob` varchar(15) default NULL,
  `email` varchar(50) default NULL,
  `sec_ques` varchar(50) default NULL,
  `sec_ans` varchar(50) default NULL,
  `image` varchar(100) default NULL,
  `imgname` varchar(100) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` (`username`, `password`, `name`, `gender`, `mobile`, `address`, `country`, `dob`, `email`, `sec_ques`, `sec_ans`, `image`, `imgname`) VALUES 
('admin', 'admin', 'Shubham Aggarwal', 'Male', '9876856407', 'Nahan', 'India', '07/09/1995', 'onlinebank4us@gmail.com', 'What is your favorite color?', 'Black', 'C:\\Users\\Shubham\\Downloads\\Compressed\\eclipse\\admin.jpg', 'admin.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `car_loan`
-- 

CREATE TABLE `car_loan` (
  `accno` varchar(20) NOT NULL,
  `token` varchar(10) default NULL,
  `model` varchar(50) default NULL,
  `variant` varchar(50) default NULL,
  `salary` varchar(20) default NULL,
  `loan` varchar(20) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `car_loan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `edu_loan`
-- 

CREATE TABLE `edu_loan` (
  `accno` varchar(20) NOT NULL,
  `token` varchar(10) default NULL,
  `college_name` varchar(50) default NULL,
  `stream` varchar(50) default NULL,
  `duration` varchar(20) default NULL,
  `loan` varchar(20) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `edu_loan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `emp`
-- 

CREATE TABLE `emp` (
  `username` varchar(50) NOT NULL,
  `password` varchar(30) character set latin1 collate latin1_general_cs default NULL,
  `name` varchar(50) default NULL,
  `gender` varchar(20) default NULL,
  `mobile` varchar(12) default NULL,
  `address` varchar(5000) default NULL,
  `country` varchar(50) default NULL,
  `dob` varchar(15) default NULL,
  `email` varchar(50) default NULL,
  `sec_ques` varchar(50) default NULL,
  `sec_ans` varchar(50) default NULL,
  `image` varchar(100) default NULL,
  `imgname` varchar(100) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `emp`
-- 

INSERT INTO `emp` (`username`, `password`, `name`, `gender`, `mobile`, `address`, `country`, `dob`, `email`, `sec_ques`, `sec_ans`, `image`, `imgname`) VALUES 
('Demo', '123456', 'shubham', 'Male', '24287676', 'nahan', 'India', '07/10/1934', 'demo@abc.com', 'What is your nickname?', 'demo', NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `home_loan`
-- 

CREATE TABLE `home_loan` (
  `accno` varchar(20) NOT NULL,
  `token` varchar(10) default NULL,
  `city` varchar(50) default NULL,
  `salary` varchar(20) default NULL,
  `loan` varchar(20) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `home_loan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `mail`
-- 

CREATE TABLE `mail` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) default NULL,
  `email` varchar(50) default NULL,
  `mobile` varchar(12) default NULL,
  `message` varchar(5000) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `mail`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `menu`
-- 

CREATE TABLE `menu` (
  `menu` varchar(50) NOT NULL,
  `menupath` varchar(50) default NULL,
  `submenu` varchar(50) default NULL,
  `submenupath` varchar(50) default NULL,
  `id` int(20) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `menu` (`menu`),
  UNIQUE KEY `submenu` (`submenu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `menu`
-- 

INSERT INTO `menu` (`menu`, `menupath`, `submenu`, `submenupath`, `id`) VALUES 
('Home', 'index.jsp', NULL, NULL, 1),
('About', 'about.jsp', NULL, NULL, 12),
('Markets', 'markets.jsp', NULL, NULL, 13),
('Services', 'services.jsp', NULL, NULL, 14),
('Mail Us', 'mail.jsp', NULL, NULL, 16);

-- --------------------------------------------------------

-- 
-- Table structure for table `personal_loan`
-- 

CREATE TABLE `personal_loan` (
  `accno` varchar(10) NOT NULL,
  `token` varchar(10) default NULL,
  `salary` varchar(20) default NULL,
  `loan` varchar(20) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `personal_loan`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `review`
-- 

CREATE TABLE `review` (
  `accno` varchar(20) NOT NULL,
  `name` varchar(100) default NULL,
  `review` varchar(500) default NULL,
  `img` varchar(50) NOT NULL,
  `imgpath` varchar(100) NOT NULL,
  PRIMARY KEY  (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `review`
-- 

INSERT INTO `review` (`accno`, `name`, `review`, `img`, `imgpath`) VALUES 
('001', 'Prashant Syn', 'The Invincible Bank is one of the best bank in India. One can easily transfer funds or get account details online and can apply for loan or credit card easily.', '4.jpg', 'D:/Eclipse/Online Bank/WebContent/user_panel/images/4.jpg'),
('123', 'Shubham Aggarwal', 'This bank provide vaious facilities like internet banking, loan and many more. One can easily apply for loan or check and transfer funds while sitting at home.', 'admin.jpg', 'D:/Eclipse/Online Bank/WebContent/user_panel/images/admin.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `sec_ques`
-- 

CREATE TABLE `sec_ques` (
  `ques` varchar(100) NOT NULL,
  PRIMARY KEY  (`ques`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `sec_ques`
-- 

INSERT INTO `sec_ques` (`ques`) VALUES 
('In what year was your father born?'),
('What is your birth place?'),
('What is your college name?'),
('What is your favorite book?'),
('What is your favorite color?'),
('What is your nickname?'),
('What is your pets name?'),
('What was the name of your elementary / primary school?'),
('Who is your favorite actor?');

-- --------------------------------------------------------

-- 
-- Table structure for table `services`
-- 

CREATE TABLE `services` (
  `id` int(11) NOT NULL auto_increment,
  `imgname` varchar(50) default NULL,
  `imgpath` varchar(500) default NULL,
  `title` varchar(50) default NULL,
  `data` varchar(5000) default NULL,
  `linkname` varchar(50) default NULL,
  `link` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `imgname` (`imgname`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `services`
-- 

INSERT INTO `services` (`id`, `imgname`, `imgpath`, `title`, `data`, `linkname`, `link`) VALUES 
(2, 'debitcard.png', 'D:/Eclipse/Online Bank/WebContent/images/debitcard.png', 'Apply for Debit Card', '<p>Your INVINCIBLE Bank Debit Card at a glance</p> <ul> <li><span class="glyphicon glyphicon-share-alt"></span> Pay for anything from eating out with family to a vacation abroad</li> <li><span class="glyphicon glyphicon-share-alt"></span> Shop and book your travel tickets online</li> <li><span class="glyphicon glyphicon-share-alt"></span> Pay your utility bills at a go</li> <li><span class="glyphicon glyphicon-share-alt"></span> Withdraw cash all around the world</li> </ul>', 'apply', 'debitcard.jsp'),
(4, 'ebank.jpg', 'D:/Eclipse/Online Bank/WebContent/images/ebank.jpg', 'Internet Banking', '<p>Internet Banking is a convenient way to do banking from the comfort of your home or office. </p>\r\n<ul>\r\n<li><span class="glyphicon glyphicon-share-alt"></span>\r\nEdit Profile</li>\r\n<li><span class="glyphicon glyphicon-share-alt"></span>\r\nCheck Account Statement</li>\r\n<li><span class="glyphicon glyphicon-share-alt"></span>\r\nTransfer Funds</li>\r\n<li><span class="glyphicon glyphicon-share-alt"></span>\r\nOpen a fixed deposit</li>\r\n</ul>', 'apply', 'user_panel/index.jsp'),
(5, 'Major-Credit-Card-Logo-PNG-Pic.png', 'D:/Eclipse/Online Bank/WebContent/images/Major-Credit-Card-Logo-PNG-Pic.png', 'APPLY FOR CREDIT CARD', '<p>Your INVINCIBLE Bank Credit Card at a glance</p> <ul> <li><span class="glyphicon glyphicon-share-alt"></span> Attractive Reward Points</li> <li><span class="glyphicon glyphicon-share-alt"></span> Convenient utility bill payment</li> <li><span class="glyphicon glyphicon-share-alt"></span>Revolving credit facility</li> <li><span class="glyphicon glyphicon-share-alt"></span> Pay for anything from eating out with family to a vacation abroad</li> </ul>', 'Apply', 'creditcard.jsp');

-- --------------------------------------------------------

-- 
-- Table structure for table `trading`
-- 

CREATE TABLE `trading` (
  `id` int(11) NOT NULL auto_increment,
  `imgname` varchar(500) default NULL,
  `imgpath` varchar(500) default NULL,
  `title` varchar(50) NOT NULL,
  `data` varchar(5000) default NULL,
  `linkname` varchar(50) default NULL,
  `link` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `trading`
-- 

INSERT INTO `trading` (`id`, `imgname`, `imgpath`, `title`, `data`, `linkname`, `link`) VALUES 
(1, 'loan.jpg', 'D:/Eclipse/Online Bank/WebContent/images/loan.jpg', 'Apply For Loan', 'Dreaming of a vacation, a perfect wedding, home renovation or a much desired gadget, you no longer need to wait to realize your dreams. Make life picture perfect with Invincible Bank Personal Loans.', 'Apply', 'loan.jsp');

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `accno` varchar(20) NOT NULL,
  `acctype` varchar(20) default NULL,
  `bal` varchar(50) default NULL,
  `name` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `mob` varchar(10) default NULL,
  `address` varchar(80) default NULL,
  `country` varchar(20) default NULL,
  `gender` varchar(20) default NULL,
  `username` varchar(50) default NULL,
  `password` varchar(50) character set latin1 collate latin1_general_cs default NULL,
  `sec_ques` varchar(100) default NULL,
  `sec_ans` varchar(50) default NULL,
  `transaction_pass` varchar(30) default NULL,
  `beneficiary_name` varchar(5000) default NULL,
  `beneficiary_accno` varchar(5000) default NULL,
  `beneficiary_type` varchar(5000) default NULL,
  `otp` varchar(10) default NULL,
  `fd` varchar(50) default NULL,
  PRIMARY KEY  (`accno`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`accno`, `acctype`, `bal`, `name`, `email`, `mob`, `address`, `country`, `gender`, `username`, `password`, `sec_ques`, `sec_ans`, `transaction_pass`, `beneficiary_name`, `beneficiary_accno`, `beneficiary_type`, `otp`, `fd`) VALUES 
('001', 'Savings', '9999990000', 'Prashant Syn', 'abc@gmail.com', '9876856023', 'Chandigarh', 'India', 'Male', 'prashant', '123456', 'What is your college name?', 'CGC', NULL, NULL, NULL, NULL, NULL, '10000'),
('123', 'Savings', '200', 'Shubham Aggarwal', 'aggrawal.shubham786@gmail.com', '9876856409', 'Nahan', 'India', 'Male', 'shubham', 'cooldude', 'What is your college name?', 'cgc', 'cooldude', 'Shubham Saini', '909', 'Savings', NULL, NULL),
('909', 'Savings', '17900', 'Shubham Saini', 'shubham.k909@gmail.com', '9876846876', 'chd', 'India', 'Male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
