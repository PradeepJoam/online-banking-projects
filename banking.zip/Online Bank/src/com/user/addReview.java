package com.user;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.controller.Connectivity;

/**
 * Servlet implementation class addReview
 */
@WebServlet("/addReview")
public class addReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String UPLOAD_DIRECTORY1 = "D:/Eclipse/Online Bank/WebContent/user_panel/images/";
        File f = new File(UPLOAD_DIRECTORY1 + "/" );
        f.mkdir();
        String UPLOAD_DIRECTORY = "D:/Eclipse/Online Bank/WebContent/user_panel/images/";
        String name = null,review=null,accno=null;
        HttpSession session=request.getSession();
        String username=(String)session.getAttribute("name");
        Review obj=new Review();
		
		try
		{
			obj.getAccno(username);
			if(obj.rst.next())
			{
				name=obj.rst.getString("name");
				accno=obj.rst.getString("accno");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
        String attachment1 = null;

        if (ServletFileUpload.isMultipartContent(request)) 
        {
            try 
            {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                for (FileItem item : multiparts) 
                {
                    if (!item.isFormField()) 
                    {
                        if (item.getFieldName().equals("file")) 
                        {
                            attachment1 = new File(item.getName()).getName();
                            item.write(new File(UPLOAD_DIRECTORY + attachment1));
                        }
                    } 
                    else 
                    {

                    	
                    	if (item.getFieldName().equals("review")) 
                        {
                            review = item.getString();
                        }
                        
                    }
                }
            } 
            catch (Exception ex) 
            {
                System.out.println("File Upload Failed due to " + ex);

            }
        } 
        else 
        {
        	System.out.println("Sorry this Servlet only handles file upload request");
        }

      
		    String path=UPLOAD_DIRECTORY + attachment1;
			
			try 
			{	
				String img=attachment1;
				String imgpath=path;
				obj.setReview(name,review,img,imgpath); 
				obj.chkData(accno);
				if(obj.rst.next())
				{
					obj.updateReview(accno);
					if(obj.i>0)
					{
						out.print("<script>alert('Review updated successfully!')</script>");
						response.setHeader("Refresh", "0.00001;url=user_panel/review.jsp");	
					}
					else
					{
						out.print("<script>alert('Error while updating review!')</script>");
						response.setHeader("Refresh", "0.00001;url=user_panel/review.jsp");
					}
				}
				else
				{
					obj.addReview(accno);
					if(obj.i>0)
					{
						out.print("<script>alert('Review added successfully!')</script>");
						response.setHeader("Refresh", "0.00001;url=user_panel/review.jsp");	
					}
					else
					{
						out.print("<script>alert('Error while adding review!')</script>");
						response.setHeader("Refresh", "0.00001;url=user_panel/review.jsp");
					}
				}
				
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
