package com.user;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Review {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1;
	public int i;
	
	public void getAccno(String username) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( ); 
        rst=st.executeQuery("select accno,name from user where username='"+username+"' ");

	}
	
	public void chkData(String accno) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( ); 
        rst=st.executeQuery("select accno from review where accno='"+accno+"' ");

	}
	
	public void setReview(String name,String review,String img,String imgpath) 
	{
		info.setReview(review);
		info.setUser_name(name);
		info.setImg(img);
		info.setImgpath(imgpath);
	}
	
	public void updateReview(String accno) throws SQLException
	{
		obj.Connec(); 
		pst=obj.con.prepareStatement("update review set name=?,review=?,img=?,imgpath=? where accno='"+accno+"' ");
		pst.setString(1, info.getUser_name());
		pst.setString(2, info.getReview());
		pst.setString(3, info.getImg());
		pst.setString(4, info.getImgpath());
		i=pst.executeUpdate();
	}
	 
	public void addReview(String accno) throws SQLException
	{
		obj.Connec(); 
		pst=obj.con.prepareStatement("insert into review values(?,?,?,?,?)");
		pst.setString(1, accno);
		pst.setString(2, info.getUser_name());
		pst.setString(3, info.getReview());
		pst.setString(4, info.getImg());
		pst.setString(5, info.getImgpath());
		i=pst.executeUpdate();
	}
}
