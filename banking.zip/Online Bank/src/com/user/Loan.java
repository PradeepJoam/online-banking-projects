package com.user;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Loan {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1;
	public int i;
	
	public void personalLoan(String accno,String amt, String salary,String token)
	{
		info.setUser_accno(accno);
		info.setLoan_amount(amt);
		info.setSalary(salary);
		info.setToken(token);
		
	}
	
	public void personalLoan() throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("insert into personal_loan values(?,?,?,?,?) ");
		pst.setString(1, info.getUser_accno());
		pst.setString(2, info.getToken());
		pst.setString(3, info.getSalary());
		pst.setString(4, info.getLoan_amount());
		pst.setString(5, "pending");
		i=pst.executeUpdate();
	}
	
	public void check() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from personal_loan where accno='"+info.getUser_accno()+"' ");
	}
	
	public void displayPersonalLoan(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select personal_loan.token,user.name,user.email,user.gender,user.mob,user.address,user.country,personal_loan.accno,user.acctype,personal_loan.salary,personal_loan.loan from personal_loan INNER JOIN user ON personal_loan.accno=user.accno where personal_loan.accno='"+accno+"' ");
		
		
	}
	
	public void update_personalLoan() throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update personal_loan set token=?,salary=?,loan=?,status=? where accno='"+info.getUser_accno()+"' ");
		pst.setString(1, info.getToken());
		pst.setString(2, info.getSalary());
		pst.setString(3, info.getLoan_amount());  
		pst.setString(4, "pending");  
		i=pst.executeUpdate();
	}
	
	
	public void eduLoan(String accno,String clgName, String Stream, String duration, String amt,String token)
	{
		info.setUser_accno(accno);
		info.setLoan_amount(amt);
		info.setClgName(clgName);
		info.setToken(token);
		info.setStream(Stream);
		info.setDuration(duration);
		
		
	}
	
	public void update_eduLoan() throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update edu_loan set token=?,college_name=?,stream=?,duration=?,loan=?,status=? where accno='"+info.getUser_accno()+"' ");
		pst.setString(1, info.getToken());
		pst.setString(2, info.getClgName());
		pst.setString(3, info.getStream());  
		pst.setString(4, info.getDuration());  
		pst.setString(5, info.getLoan_amount());
		pst.setString(6, "pending");
		i=pst.executeUpdate();
	}
 
	public void eduLoan() throws SQLException
	{ 
		
		obj.Connec();
		pst=obj.con.prepareStatement("insert into edu_loan values(?,?,?,?,?,?,?)");
		pst.setString(1, info.getUser_accno());
		pst.setString(2, info.getToken());
		pst.setString(3, info.getClgName());
		pst.setString(4, info.getStream());
		pst.setString(5, info.getDuration());
		pst.setString(6, info.getLoan_amount());
		pst.setString(7, "pending");
		i=pst.executeUpdate();
	} 
	
	public void displayEduLoan(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select edu_loan.token,user.name,user.email,user.gender,user.mob,user.address,user.country,edu_loan.accno,user.acctype,edu_loan.college_name,edu_loan.stream,edu_loan.duration,edu_loan.loan from edu_loan INNER JOIN user ON edu_loan.accno=user.accno where edu_loan.accno='"+accno+"' ");

	}
	
	public void checkEduLoan() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from edu_loan where accno='"+info.getUser_accno()+"' ");
	}
	
	
	public void carLoan(String accno,String model, String variant, String salary, String amt,String token)
	{
		info.setUser_accno(accno);
		info.setLoan_amount(amt);
		info.setModel(model);
		info.setVariant(variant);
		info.setSalary(salary);
		info.setToken(token); 
		
		
	}
	
	public void update_carLoan() throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update car_loan set token=?,model=?,variant=?,salary=?,loan=?,status=? where accno='"+info.getUser_accno()+"' ");
		pst.setString(1, info.getToken());
		pst.setString(2, info.getModel());
		pst.setString(3, info.getVariant());  
		pst.setString(4, info.getSalary());  
		pst.setString(5, info.getLoan_amount()); 
		pst.setString(6, "pending"); 
		i=pst.executeUpdate();
	}
 
	public void carLoan() throws SQLException
	{ 
		
		obj.Connec();
		pst=obj.con.prepareStatement("insert into car_loan values(?,?,?,?,?,?,?)");
		pst.setString(1, info.getUser_accno());
		pst.setString(2, info.getToken());
		pst.setString(3, info.getModel());
		pst.setString(4, info.getVariant());
		pst.setString(5, info.getSalary());
		pst.setString(6, info.getLoan_amount());
		pst.setString(7, "pending");
		i=pst.executeUpdate();
	} 
	
	public void displayCarLoan(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select car_loan.token,user.name,user.email,user.gender,user.mob,user.address,user.country,car_loan.accno,user.acctype,car_loan.model,car_loan.variant,car_loan.salary,car_loan.loan from car_loan INNER JOIN user ON car_loan.accno=user.accno where car_loan.accno='"+accno+"' ");

	}
	
	public void checkCarLoan() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from car_loan where accno='"+info.getUser_accno()+"' ");
	}
	
	
	public void homeLoan(String accno,String city, String salary, String amt,String token)
	{
		info.setUser_accno(accno);
		info.setLoan_amount(amt);
		info.setCity(city);
		info.setSalary(salary);
		info.setToken(token); 
		
		
	}
	
	public void update_homeLoan() throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update home_loan set token=?,city=?,salary=?,loan=?,status=? where accno='"+info.getUser_accno()+"' ");
		pst.setString(1, info.getToken());
		pst.setString(2, info.getCity());
		pst.setString(3, info.getSalary());  
		pst.setString(4, info.getLoan_amount());  
		pst.setString(5, "pending");
		i=pst.executeUpdate();
	}
 
	public void homeLoan() throws SQLException
	{ 
		
		obj.Connec();
		pst=obj.con.prepareStatement("insert into home_loan values(?,?,?,?,?,?)");
		pst.setString(1, info.getUser_accno());
		pst.setString(2, info.getToken());
		pst.setString(3, info.getCity());
		pst.setString(4, info.getSalary());
		pst.setString(5, info.getLoan_amount());
		pst.setString(6, "pending");
		i=pst.executeUpdate();
	} 
	
	public void displayHomeLoan(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select home_loan.token,user.name,user.email,user.gender,user.mob,user.address,user.country,home_loan.accno,user.acctype,home_loan.city,home_loan.salary,home_loan.loan from home_loan INNER JOIN user ON home_loan.accno=user.accno where home_loan.accno='"+accno+"' ");

	}
	
	public void checkHomeLoan() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from home_loan where accno='"+info.getUser_accno()+"' ");
	}
	
}
 