package com.user;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Card {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1;
	public int i;
	
	public void debitCard(String accno)
	{ 
		info.setUser_accno(accno);
	}
	
	public void debitCard() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select name,email,gender,mob,address,country,accno,acctype from user where accno='"+info.getUser_accno()+"' ");
	}
	
}
