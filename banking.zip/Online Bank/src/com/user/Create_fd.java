package com.user;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Create_fd {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	Statement st;
	PreparedStatement pst;
	public ResultSet rst;
	public int i;
	
	public void createFD(String name, String amt) 
	{
		
		info.setUser_username(name);
		info.setUser_bal(amt);
	
	}
	
	public void createFD(String bal) throws SQLException
	{
		conn.Connec();
		pst=conn.con.prepareStatement("update user set fd=?,bal=? where username='"+info.getUser_username()+"' ");
		pst.setString(1, info.getUser_bal());
		pst.setString(2, bal);
		
		i=pst.executeUpdate(); 

	}
	
	public void chkBal() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select bal from user where username='"+info.getUser_username()+"' ");
		
	}
	
	public void chkFD() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select fd from user where username='"+info.getUser_username()+"' ");
		
	}
}
