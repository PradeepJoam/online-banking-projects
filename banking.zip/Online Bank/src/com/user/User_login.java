package com.user;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class User_login {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	Statement st;
	PreparedStatement pst;
	public ResultSet rst;
	public int i;
	public void setUser(String name, String pass) 
	{
		
		info.setUser_username(name);
		info.setUser_password(pass);
	
	}
	
	public void getUser() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select * from user where username='"+info.getUser_username()+"' and password='"+info.getUser_password()+"' ");
		
	}
	
	public void createUser(String accno, String name,String pass, String ques, String ans) 
	{
		info.setUser_accno(accno);
		info.setUser_username(name);
		info.setUser_password(pass);
		info.setUser_ques(ques);
		info.setUser_ans(ans);
		
		
	}
	
	public void createUser() throws SQLException
	{
		conn.Connec();
		pst=conn.con.prepareStatement("update user set username=?,password=?,sec_ques=?,sec_ans=? where accno='"+info.getUser_accno()+"' ");
		pst.setString(1, info.getUser_username());
		pst.setString(2, info.getUser_password());
		pst.setString(3, info.getUser_ques());
		pst.setString(4, info.getUser_ans());
		
		i=pst.executeUpdate();
	}
	
	
	public void forget(String accno, String name, String ques, String ans)
	{
		info.setUser_accno(accno);
		info.setUser_username(name);
		info.setUser_ques(ques);
		info.setUser_ans(ans);
		
	}
	
	public void forget_check() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select sec_ques,sec_ans from user where username='"+info.getUser_username()+"' and accno='"+info.getUser_accno()+"' ");
			
	}
	
	public void forget(String name,String pass) throws SQLException
	{
		info.setUser_username(name);
		info.setUser_password(pass);
		
			
	}
	public void forget() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update user set password=? where username='"+info.getUser_username()+"' ");
			pst.setString(1, info.getUser_password());
			
			i=pst.executeUpdate();
			
	}
	
	public void setProfile(String name, String gender, String mobile, String address, String country, String email)
	{
		
		info.setUser_name(name);
		info.setUser_gender(gender);
		info.setUser_mob(mobile);
		info.setUser_address(address);
		info.setUser_country(country);
		info.setUser_email(email);
	} 
	
	public void getProfile(String name) throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("update user set name=?,gender=?,mob=?,address=?,country=?,email=? where username='"+name+"' ");
			pst.setString(1, info.getUser_name());
			pst.setString(2, info.getUser_gender());
			pst.setString(3, info.getUser_mob()); 
			pst.setString(4, info.getUser_address());
			pst.setString(5, info.getUser_country());
			pst.setString(6, info.getUser_email());
			i=pst.executeUpdate();
			
	}
	
	
	public void security(String name, String ques,String ans) throws SQLException
	{
		info.setUser_username(name);
		info.setUser_ques(ques);
		info.setUser_ans(ans);
		
	} 
	
	public void security() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update user set sec_ques=?,sec_ans=? where username='"+info.getUser_username()+"' ");
			
			pst.setString(1, info.getUser_ques());
			pst.setString(2, info.getUser_ans());
			
			i=pst.executeUpdate();
			
	}
	
	
	public void changeTransaction(String accno, String name,String pass) throws SQLException
	{
		info.setUser_accno(accno);
		info.setUser_username(name);
		info.setUser_password(pass);
		
			
	}
	public void changeTransaction() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update user set transaction_pass=? where username='"+info.getUser_username()+"' and accno='"+info.getUser_accno()+"' ");
			pst.setString(1, info.getUser_password());
			
			i=pst.executeUpdate();
			
	}
} 
