package com.user;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.controller.Connectivity;
import com.view.Info;

public class Beneficiary {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1;
	public int i;
	
	public void setBeneficiary(String name, String accno, String acctype)
	{
		info.setBeneficiary_accno(accno);
		info.setBeneficiary_name(name);
		info.setBeneficiary_acctype(acctype);
	} 
	
	public void checkBeneficiary(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select name from user where accno='"+accno+"' ");
	}
	 
	public void updateBeneficiary(String username) throws SQLException 
	{
		obj.Connec();
		pst=obj.con.prepareStatement("update user set beneficiary_name=?,beneficiary_accno=?,beneficiary_type=? where username='"+username+"' ");
		pst.setString(1, info.getBeneficiary_name());
		pst.setString(2, info.getBeneficiary_accno());
		pst.setString(3, info.getBeneficiary_acctype());
		i=pst.executeUpdate();
	}
	
	public void getBeneficiary(String username) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from user where username='"+username+"' ");
	}
	
	
	
}
