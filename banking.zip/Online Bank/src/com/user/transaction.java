package com.user;

import java.sql.*;
import com.controller.Connectivity;
import com.view.Info;

public class transaction {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1; 
	public int i;
	
	public void OTP(String username,String otp) throws SQLException
	{
		obj.Connec(); 
		pst=obj.con.prepareStatement("update user set otp=? where username='"+username+"' ");
		pst.setString(1, otp);
		i=pst.executeUpdate();
	}
	
	public void getEmail(String username) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( ); 
        rst=st.executeQuery("select email from user where username='"+username+"' ");

	}
	
	public void chk_transactionPass(String username) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( ); 
        rst=st.executeQuery("select transaction_pass,otp from user where username='"+username+"' ");

	}
	
	public void transfer(String accno, String bal) 
	{
		info.setUser_accno(accno);
		info.setUser_bal(bal);
	}
	
	
	public void chk_transfer(String username) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( );
        rst=st.executeQuery("select bal from user where username='"+username+"' ");

	}
	
	public void getAccno(String username) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( );
        rst=st.executeQuery("select accno from user where username='"+username+"' ");

	}
	
	
	public void transfer(String u_accno) throws SQLException
	{
		obj.Connec(); 
		st=obj.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+u_accno+"' ");

        if(rst.next())
        {	int temp=Integer.parseInt(info.getUser_bal());
        	int amt=Integer.parseInt(rst.getString(1))-temp;
	 		info.setUser_bal(String.valueOf(amt));
	 		pst=obj.con.prepareStatement("update user set bal=? where accno='"+u_accno+"' ");
	         	pst.setString(1,info.getUser_bal());
	         	pst.executeUpdate();
 		 	
	         rst1=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");
	         if(rst1.next())
	         {
	        	int amt1=Integer.parseInt(rst1.getString(1))+temp;
	        	info.setUser_bal(String.valueOf(amt1));
	       		pst1=obj.con.prepareStatement("update user set bal=? where accno='"+info.getUser_accno()+"' ");
	       		pst1.setString(1,info.getUser_bal());
	       		i=pst1.executeUpdate();
			
	         } 
        	
	    }
        else
       	 System.out.println("Invalid Account Number");

			
	}
}
