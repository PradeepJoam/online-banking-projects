package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Admin_Login;

/**
 * Servlet implementation class createAdmin
 */
@WebServlet("/createAdmin")
public class createAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public createAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
				
		String name=request.getParameter("username");
		String pass=request.getParameter("password");
		String ques=request.getParameter("ques");
		String ans=request.getParameter("ans");
		String acc=request.getParameter("acc");
		
		System.out.println(name+pass+ques+ans+acc);
		if(ques.equals("!--Security Question--!"))
		{
			out.print("<script>alert('Must select security question!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
			
		}
		else if(acc.equals("!--Select Account--!"))
		{
			out.print("<script>alert('Must select account!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
			
		}
		else
		{
			if(acc.equals("admin"))
			{
					try 
					{
						Admin_Login obj=new Admin_Login();
						obj.setAdminacc(name,pass,ques,ans);
						obj.getAdminacc();
						if(obj.i>0)
						{
							out.print("<script>alert('Admin account created successfully!')</script>");
							response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							
						}
					}
					catch(Exception e)
					{
						
						out.print("<script>alert('Error while creating admin account!')</script>");
						response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
					}
			}
			else if(acc.equals("employer"))
			{
				try 
				{
					Admin_Login obj=new Admin_Login();
					obj.setEmpacc(name,pass,ques,ans);
					obj.getEmpacc();
					if(obj.i>0)
					{
						out.print("<script>alert('Employer account created successfully!')</script>");
						response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
						
					}
				}
				catch(Exception e)
				{
					
					out.print("<script>alert('Error while creating employer account!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
