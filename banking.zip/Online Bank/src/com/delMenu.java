package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Menu_bar;

/**
 * Servlet implementation class delMenu
 */
@WebServlet("/delMenu")
public class delMenu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delMenu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String menuName=request.getParameter("menuName");
		String subMenuName=request.getParameter("submenuName");
		
		if(menuName.equals("!--Select Menu Item--!"))
		{
			out.print("<script>alert('Must select Menu Item!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
		}
		else
		{
			try
			{
				Menu_bar obj=new Menu_bar();
				obj.delMenu(menuName);
				obj.delMenu();
				if(obj.i>0)
				{ 
					out.print("<script>alert('Menu Item Deleted!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
				else
				{
					out.print("<script>alert('Error while deleting menu item!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				out.print("<script>alert('Error!')</script>");
				response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
			}
		}	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
