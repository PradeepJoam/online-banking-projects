package com.employer;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Emp_login {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	Statement st;
	PreparedStatement pst;
	public ResultSet rst;
	public int i;
	public void setEmp(String name, String pass) 
	{
		
		info.setEmp_uname(name);
		info.setEmp_pass(pass);
	
	}
	
	public void getEmp() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select * from emp where username='"+info.getEmp_uname()+"' and password='"+info.getEmp_pass()+"' ");
		
	}
	
	public void setProfile(String name, String gender, String mobile, String address, String country, String dob, String email)
	{
		
		info.setEmp_name(name);
		info.setEmp_gender(gender);
		info.setEmp_mobile(mobile);
		info.setEmp_address(address);
		info.setEmp_country(country);
		info.setEmp_dob(dob);
		info.setEmp_email(email);
	} 
	
	public void getProfile(String name) throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("update emp set name=?,gender=?,mobile=?,address=?,country=?,dob=?,email=? where username='"+name+"' ");
			pst.setString(1, info.getEmp_name());
			pst.setString(2, info.getEmp_gender());
			pst.setString(3, info.getEmp_mobile());
			pst.setString(4, info.getEmp_address());
			pst.setString(5, info.getEmp_country());
			pst.setString(6, info.getEmp_dob());
			pst.setString(7, info.getEmp_email());
			i=pst.executeUpdate();
			
	}
	
	
	public void forget(String name, String ques, String ans)
	{
		
		info.setEmp_uname(name);
		info.setEmp_ques(ques);
		info.setEmp_ans(ans);
		
	}
	
	public void forget_check() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select sec_ques,sec_ans from emp where username='"+info.getEmp_uname()+"' ");
			
	}
	
	public void forget(String name,String pass) throws SQLException
	{
		info.setEmp_uname(name);
		info.setEmp_pass(pass);
		
			
	}
	public void forget() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update emp set password=? where username='"+info.getEmp_uname()+"' ");
			pst.setString(1, info.getEmp_pass());
			
			i=pst.executeUpdate();
			
	}
	
	
	public void security(String name, String ques,String ans) throws SQLException
	{
		info.setEmp_uname(name);
		info.setEmp_ques(ques);
		info.setEmp_ans(ans);
		
	} 
	
	public void security() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update emp set sec_ques=?,sec_ans=? where username='"+info.getEmp_uname()+"' ");
			
			System.out.println(info.getEmp_uname() + info.getEmp_ques() + info.getEmp_ans());
			pst.setString(1, info.getEmp_ques());
			pst.setString(2, info.getEmp_ans());
			
			i=pst.executeUpdate();
			
	}
	
	
}
