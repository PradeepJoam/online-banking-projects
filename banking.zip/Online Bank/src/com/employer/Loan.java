package com.employer;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Loan {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst,pst1;
	public Statement st,st1;
	public ResultSet rst,rst1;
	public int i;
	
	public void update_personalLoan(String token) throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update personal_loan set status=? where accno='"+token+"' ");
		pst.setString(1, "approved");
		i=pst.executeUpdate();
	}
	
	public void personalLoan_data(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select token from personal_loan where accno='"+accno+"' ");
	}
	
	public void personalLoan_email(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select email from user where accno='"+accno+"' ");
	}
	
	//home loan
	public void update_homeLoan(String token) throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update home_loan set status=? where accno='"+token+"' ");
		pst.setString(1, "approved");
		i=pst.executeUpdate();
	}
	
	public void homeLoan_data(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select token from home_loan where accno='"+accno+"' ");
	}
	
	public void homeLoan_email(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select email from user where accno='"+accno+"' ");
	}
	
	
	//car loan
	
	public void update_carLoan(String token) throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update car_loan set status=? where accno='"+token+"' ");
		pst.setString(1, "approved");
		i=pst.executeUpdate();
	}
	
	public void carLoan_data(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select token from car_loan where accno='"+accno+"' ");
	}
	
	public void carLoan_email(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select email from user where accno='"+accno+"' ");
	}
	
	//edu loan
	
	public void update_eduLoan(String token) throws SQLException
	{ 
		obj.Connec();
		pst=obj.con.prepareStatement("update edu_loan set status=? where accno='"+token+"' ");
		pst.setString(1, "approved");
		i=pst.executeUpdate();
	}
	
	public void eduLoan_data(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select token from edu_loan where accno='"+accno+"' ");
	}
	
	public void eduLoan_email(String accno) throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select email from user where accno='"+accno+"' ");
	}
	
}
