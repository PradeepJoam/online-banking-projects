package com.employer;
import java.sql.*;

import javax.swing.JOptionPane;

import com.controller.Connectivity;

import com.view.Info;

public class Emp_user {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	Statement st;
	PreparedStatement pst,pst1;
	public ResultSet rst,rst1;
	public int i;
	
	public void createUser(String accno, String acctype,String bal, String name, String email, String mob, String add, String country, String gender) 
	{
		info.setUser_accno(accno);
		info.setUser_acctype(acctype);
		info.setUser_bal(bal);
		info.setUser_name(name);
		info.setUser_email(email);
		info.setUser_mob(mob);
		info.setUser_address(add);
		info.setUser_country(country);
		info.setUser_gender(gender);
		
		 
	}
	
	public void createUser() throws SQLException
	{
		conn.Connec();
		pst=conn.con.prepareStatement("insert into user (accno,acctype,bal,name,email,mob,address,country,gender) values(?,?,?,?,?,?,?,?,?)");
		pst.setString(1, info.getUser_accno());
		pst.setString(2, info.getUser_acctype());
		pst.setString(3, info.getUser_bal());
		pst.setString(4, info.getUser_name());
		pst.setString(5, info.getUser_email());
		pst.setString(6, info.getUser_mob());
		pst.setString(7, info.getUser_address());
		pst.setString(8, info.getUser_country());
		pst.setString(9, info.getUser_gender());
		i=pst.executeUpdate();
	}
	
	
	public void deposit(String accno,String amount) throws SQLException
	{
		info.setUser_accno(accno);
		info.setUser_bal(amount);

	}
	public void deposit() throws SQLException
	{
		conn.Connec(); 
		st=conn.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");

        if(rst.next())
        {
       	 	int amt=Integer.parseInt(rst.getString(1))+Integer.parseInt(info.getUser_bal());
       	 	info.setUser_bal(String.valueOf(amt));
       	 	pst=conn.con.prepareStatement("update user set bal=? where accno='"+info.getUser_accno()+"' ");
	 	    pst.setString(1,info.getUser_bal());
	 	    i=pst.executeUpdate();
	    }
        else
       	 System.out.println("Invalid Account Number");

			
	}
	

	public void withdraw(String accno,String amount) throws SQLException
	{
		info.setUser_accno(accno);
		info.setUser_bal(amount);

	}
	

	public void chk_withdraw() throws SQLException
	{
		conn.Connec(); 
		st=conn.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");

	}
	
	public void withdraw() throws SQLException
	{
		conn.Connec(); 
		st=conn.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");

        if(rst.next())
        {
        	int amt=Integer.parseInt(rst.getString(1))-Integer.parseInt(info.getUser_bal());
       	 	info.setUser_bal(String.valueOf(amt));
       	 	pst=conn.con.prepareStatement("update user set bal=? where accno='"+info.getUser_accno()+"' ");
	 	    pst.setString(1,info.getUser_bal());
	 	    i=pst.executeUpdate();
        	
	    }
        else
       	 System.out.println("Invalid Account Number");

			
	}
	
	
	
	
	public void transfer(String accno, String accno1, String amount) throws SQLException
	{
		info.setUser_accno(accno);
		info.setUser_acctype(accno1);
		info.setUser_bal(amount);

	}
	

	public void chk_transfer() throws SQLException
	{
		conn.Connec(); 
		st=conn.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");

	}
	
	public void transfer() throws SQLException
	{
		conn.Connec(); 
		st=conn.con.createStatement( );
        rst=st.executeQuery("select bal from user where accno='"+info.getUser_accno()+"' ");

        if(rst.next())
        {	int temp=Integer.parseInt(info.getUser_bal());
        	int amt=Integer.parseInt(rst.getString(1))-temp;
	 		info.setUser_bal(String.valueOf(amt));
	 		pst=conn.con.prepareStatement("update user set bal=? where accno='"+info.getUser_accno()+"' ");
	         	pst.setString(1,info.getUser_bal());
	         	pst.executeUpdate();
 		 	
	         rst1=st.executeQuery("select bal from user where accno='"+info.getUser_acctype()+"' ");
	         if(rst1.next())
	         {
	        	int amt1=Integer.parseInt(rst1.getString(1))+temp;
	        	info.setUser_bal(String.valueOf(amt1));
	       		pst1=conn.con.prepareStatement("update user set bal=? where accno='"+info.getUser_acctype()+"' ");
	       		pst1.setString(1,info.getUser_bal());
	       		i=pst1.executeUpdate();
			
	         }
        	
	    }
        else
       	 System.out.println("Invalid Account Number");

			
	}
}
