package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Connectivity;
import com.controller.Menu_bar;

/**
 * Servlet implementation class deletesubmenu
 */
@WebServlet("/deletesubmenu")
public class deletesubmenu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deletesubmenu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		ArrayList aList = null,aList1=null;
		String smenu1;
		String menuName=request.getParameter("menuName");
		String subMenuName=request.getParameter("submenuName");
		String subMenuPath=request.getParameter("subMenuPath");
		
		
		if(menuName.equals("!--Select Menu Item--!"))
		{
			out.print("<script>alert('Must select Menu Item!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
		}
		else if(subMenuName.equals("!--Select Sub Menu Item--!") || subMenuPath.equals("!--Select Sub Menu Path--!"))
		{
			out.print("<script>alert('Must select Sub Menu Item or path!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
		}
		else
		{
			try
			{		
					String submenu="";
					String submenupath="";
					Connectivity conn=new Connectivity();
					conn.Connec();
					Statement st1 = conn.con.createStatement();
					ResultSet rst1 = st1.executeQuery("select submenu,submenupath from menu"); 
					while(rst1.next())
					{
						submenu = rst1.getString("submenu"); 
						submenupath=rst1.getString("submenupath");
						
						if(submenupath!=null && submenu!=null)
						{
							aList= new ArrayList(Arrays.asList(submenu.split(", ")));
							aList1= new ArrayList(Arrays.asList(submenupath.split(", ")));
						}	
					}
				
					
					if(aList.size()>1)
					{
							String smenu = submenu.replace(subMenuName+',',"");
							String smenupath=submenupath.replace(subMenuPath+',',"");
							
							Menu_bar obj=new Menu_bar();
							
							obj.delMenu(menuName, smenu,smenupath);
							
							obj.delSubMenu();
							if(obj.i>0)
							{
								out.print("<script>alert('Sub Menu Item Deleted!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							}
							else
							{
								out.print("<script>alert('Error while deleting sub menu item!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							}
					}
					else
					{
						String smenu = submenu.replace(subMenuName,"");
						String smenupath=submenupath.replace(subMenuPath,"");
						
						Menu_bar obj=new Menu_bar();
						obj.delMenu(menuName, smenu,smenupath);
						
						obj.delSubMenu();
						if(obj.i>0)
						{
							
							PreparedStatement pst=conn.con.prepareStatement("update menu set submenu=?,submenupath=? where menu='"+menuName+"' ");
								pst.setString(1, null);
								pst.setString(2, null);
								pst.executeUpdate();
								out.print("<script>alert('Sub Menu Item Deleted!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
								
						}
						else
						{
							out.print("<script>alert('Error while deleting sub menu item!')</script>");
							response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
						}
				}
					
			}
			catch(Exception e)
			{
				e.printStackTrace();
				out.print("<script>alert('Error!')</script>");
				response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
