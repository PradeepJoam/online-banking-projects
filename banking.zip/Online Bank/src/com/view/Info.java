package com.view;

public class Info {
	
	String name,email,mobile,message,admin_username,admin_password,id, admin_name, admin_gender, admin_mobile, admin_address, admin_country, admin_dob,admin_email,admin_ques,admin_ans;
	String menuName,menuPath,subMenuName,subMenuPath;
	String trading_title, services_title;
	String emp_uname,emp_pass, emp_name, emp_gender, emp_mobile, emp_address, emp_country, emp_dob,emp_email,emp_ques,emp_ans;
	String user_accno, user_acctype,user_bal,user_name,user_email,user_mob,user_address,user_country,user_gender,user_username,user_password,user_ques,user_ans;
	String beneficiary_name,beneficiary_accno,beneficiary_acctype;
	String loan_type,salary,loan_amount,token;
	String clgName, stream,duration;
	String model, variant,city;
	String review,img,imgpath;
	
	
	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public String getClgName() {
		return clgName;
	}

	public void setClgName(String clgName) {
		this.clgName = clgName;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getLoan_type() {
		return loan_type;
	}

	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getLoan_amount() {
		return loan_amount;
	}

	public void setLoan_amount(String loan_amount) {
		this.loan_amount = loan_amount;
	}

	public String getBeneficiary_name() {
		return beneficiary_name;
	}

	public void setBeneficiary_name(String beneficiary_name) {
		this.beneficiary_name = beneficiary_name;
	}

	public String getBeneficiary_accno() {
		return beneficiary_accno;
	}

	public void setBeneficiary_accno(String beneficiary_accno) {
		this.beneficiary_accno = beneficiary_accno;
	}

	public String getBeneficiary_acctype() {
		return beneficiary_acctype;
	}

	public void setBeneficiary_acctype(String beneficiary_acctype) {
		this.beneficiary_acctype = beneficiary_acctype;
	}

	public String getUser_ques() {
		return user_ques;
	}

	public void setUser_ques(String user_ques) {
		this.user_ques = user_ques;
	}

	public String getUser_ans() {
		return user_ans;
	}

	public void setUser_ans(String user_ans) {
		this.user_ans = user_ans;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getUser_accno() {
		return user_accno;
	}

	public void setUser_accno(String user_accno) {
		this.user_accno = user_accno;
	}

	public String getUser_acctype() {
		return user_acctype;
	}

	public void setUser_acctype(String user_acctype) {
		this.user_acctype = user_acctype;
	}

	

	public String getUser_bal() {
		return user_bal;
	}

	public void setUser_bal(String user_bal) {
		this.user_bal = user_bal;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getUser_mob() {
		return user_mob;
	}

	public void setUser_mob(String user_mob) {
		this.user_mob = user_mob;
	}

	public String getUser_address() {
		return user_address;
	}

	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}

	public String getUser_country() {
		return user_country;
	}

	public void setUser_country(String user_country) {
		this.user_country = user_country;
	}

	public String getUser_gender() {
		return user_gender;
	}

	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}

	public String getUser_username() {
		return user_username;
	}

	public void setUser_username(String user_username) {
		this.user_username = user_username;
	}

	public String getEmp_uname() {
		return emp_uname;
	}

	public void setEmp_uname(String emp_uname) {
		this.emp_uname = emp_uname;
	}

	public String getEmp_gender() {
		return emp_gender;
	}

	public void setEmp_gender(String emp_gender) {
		this.emp_gender = emp_gender;
	}

	public String getEmp_mobile() {
		return emp_mobile;
	}

	public void setEmp_mobile(String emp_mobile) {
		this.emp_mobile = emp_mobile;
	}

	public String getEmp_address() {
		return emp_address;
	}

	public void setEmp_address(String emp_address) {
		this.emp_address = emp_address;
	}

	public String getEmp_country() {
		return emp_country;
	}

	public void setEmp_country(String emp_country) {
		this.emp_country = emp_country;
	}

	public String getEmp_dob() {
		return emp_dob;
	}

	public void setEmp_dob(String emp_dob) {
		this.emp_dob = emp_dob;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getEmp_ques() {
		return emp_ques;
	}

	public void setEmp_ques(String emp_ques) {
		this.emp_ques = emp_ques;
	}

	public String getEmp_ans() {
		return emp_ans;
	}

	public void setEmp_ans(String emp_ans) {
		this.emp_ans = emp_ans;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_pass() {
		return emp_pass;
	}

	public void setEmp_pass(String emp_pass) {
		this.emp_pass = emp_pass;
	}

	public String getServices_title() {
		return services_title;
	}

	public void setServices_title(String services_title) {
		this.services_title = services_title;
	}

	public String getTrading_title() {
		return trading_title;
	}

	public void setTrading_title(String trading_title) {
		this.trading_title = trading_title;
	}


	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public String getSubMenuName() {
		return subMenuName;
	}

	public void setSubMenuName(String subMenuName) {
		this.subMenuName = subMenuName;
	}

	public String getSubMenuPath() {
		return subMenuPath;
	}

	public void setSubMenuPath(String subMenuPath) {
		this.subMenuPath = subMenuPath;
	}

	public String getAdmin_ques() {
		return admin_ques;
	}

	public void setAdmin_ques(String admin_ques) {
		this.admin_ques = admin_ques;
	}

	public String getAdmin_ans() {
		return admin_ans;
	}

	public void setAdmin_ans(String admin_ans) {
		this.admin_ans = admin_ans;
	}

	public String getAdmin_email() {
		return admin_email;
	}

	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getAdmin_gender() {
		return admin_gender;
	}

	public void setAdmin_gender(String admin_gender) {
		this.admin_gender = admin_gender;
	}

	public String getAdmin_mobile() {
		return admin_mobile;
	}

	public void setAdmin_mobile(String admin_mobile) {
		this.admin_mobile = admin_mobile;
	}

	public String getAdmin_address() {
		return admin_address;
	}

	public void setAdmin_address(String admin_address) {
		this.admin_address = admin_address;
	}

	public String getAdmin_country() {
		return admin_country;
	}

	public void setAdmin_country(String admin_country) {
		this.admin_country = admin_country;
	}

	public String getAdmin_dob() {
		return admin_dob;
	}

	public void setAdmin_dob(String admin_dob) {
		this.admin_dob = admin_dob;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAdmin_username() {
		return admin_username;
	}

	public void setAdmin_username(String admin_username) {
		this.admin_username = admin_username;
	}

	public String getAdmin_password() {
		return admin_password;
	}

	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
