package com;
import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Admin_mailDel {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	PreparedStatement pst;
	public int i;
	public void setId(String id)
	{
		
		info.setId(id);
	}
	
	public void getId() throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("delete from mail where id='"+Integer.parseInt(info.getId())+"' ");
		
		
		i=pst.executeUpdate();
	
		
	}
}
