package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Admin_Login;

/**
 * Servlet implementation class delAdmin
 */
@WebServlet("/delAdmin")
public class delAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");

		
		if(username.equals("!--Select Admin Account--!"))
		{
			out.print("<script>alert('Must select account!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
		}
		else if(username.equals("admin"))
		{
			out.print("<script>alert('You cannot delete main admin account!')</script>");
			response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
		}
		else
		{
			try
			{
				Admin_Login obj=new Admin_Login();
				obj.deleteAdmin(username); 
				if(obj.i>0)
				{
					out.print("<script>alert('Admin Account Deleted!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
				else
				{
					out.print("<script>alert('Error while deleting admin account!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Error!");
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
