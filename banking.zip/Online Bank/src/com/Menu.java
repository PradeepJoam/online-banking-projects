package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.DynamicArray;
import com.controller.Menu_bar;

/**
 * Servlet implementation class Menu
 */
@WebServlet("/Menu")
public class Menu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Menu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String menu=request.getParameter("menuName");
		String menuPath=request.getParameter("menuPath");
		String submenu=request.getParameter("subMenuName");
		String submenuPath=request.getParameter("subMenuPath");
		
		
		try 
		{
			Menu_bar obj=new Menu_bar();
			obj.setMenu(menu, menuPath, submenu, submenuPath);
			obj.checkMenu();
			if(obj.rst.next())
			{	
				String smenu=obj.rst.getString("submenu");
				String smenupath=obj.rst.getString("submenupath");
				if(smenu=="" || smenupath=="")
				{
					String submenu1=null;
					String submenuPath1=null;
					obj.setMenu(menu, menuPath, submenu1, submenuPath1);
				}
				
				if(submenu=="" || submenuPath=="")
				{
					System.out.println("Menu Item already exist. <br> Enter Sub Menu Item!");
					out.print("<script>alert('Menu Item already exist. <br> Enter Sub Menu Item!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
				}
				else
				{
					obj.getSubMenu();
					if(obj.rst.next())
					{
						String mname=obj.rst.getString("submenu");
						String mpath=obj.rst.getString("submenupath");
						
						if(mname==null || mname=="")
						{
							obj.updateSubMenu();
							if(obj.i>0)
							{	System.out.println("Menu Item Added Successfully!");
								out.print("<script>alert('Menu Item Added Successfully!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							}
							else
							{
								System.out.println("Error while adding menu item!");
								out.print("<script>alert('Error while adding menu item!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							} 
							
						}
						else
						{	
							DynamicArray da = new DynamicArray();
							da.insert(mname);
						 	da.insert(submenu); 
						 	mname=da.convertstring();
						 	mname=mname.substring(1, mname.length() - 1);
						 	da.clear();
						 	
						 	DynamicArray da1 = new DynamicArray();
							da1.insert(mpath);
						 	da1.insert(submenuPath);
						 	mpath=da1.convertstring();
						 	mpath=mpath.substring(1, mpath.length() - 1);
						 	da1.clear();
						 	
						 	obj.setSubMenu(mname,mpath);
						
						 	obj.updateSubMenu();
							if(obj.i>0)
							{
								System.out.println("Menu Item Added Successfully!");
								out.print("<script>alert('Menu Item Added Successfully!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							}
							else
							{
								System.out.println("Error while adding menu item!");
								out.print("<script>alert('Error while adding menu item!')</script>");
								response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
							}
							
						}
						
						
						
						
						
					}
					obj.updateSubMenu();
					if(obj.i>0)
					{
						System.out.println("Menu Item Added Successfully!");
						out.print("<script>alert('Menu Item Added Successfully!')</script>");
						response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
					}
					else
					{
						System.out.println("Error while adding menu item!");
						out.print("<script>alert('Error while adding menu item!')</script>");
						response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
					}
					
				}
			}
			else
			{
				if(submenu=="" || submenuPath=="")
				{
					String submenu1=null;
					String submenuPath1=null;
					obj.setMenu(menu, menuPath, submenu1, submenuPath1);
				}
				obj.getMenu();
					if(obj.i>0)
					{
					System.out.println("Menu Item Added Successfully!");
					out.print("<script>alert('Menu Item Added Successfully!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
					}
					else
					{
					System.out.println("Error while adding menu item!");
					out.print("<script>alert('Error while adding menu item!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/admin_home.jsp");
					}
				
			}
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			out.print("<script>alert('Error while creating account!')</script>");
			
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
