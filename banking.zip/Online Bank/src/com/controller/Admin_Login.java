package com.controller;
import java.sql.*;

import com.view.Info;
public class Admin_Login {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	Statement st;
	PreparedStatement pst;
	public ResultSet rst;
	public int i;
	public void setAdmin(String name, String pass)
	{
		
		info.setAdmin_username(name);
		info.setAdmin_password(pass);
	
	}
	
	public void getAdmin() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select * from admin where username='"+info.getAdmin_username()+"' and password='"+info.getAdmin_password()+"' ");
		
	}
	
	public void setProfile(String name, String gender, String mobile, String address, String country, String dob, String email)
	{
		
		info.setAdmin_name(name);
		info.setAdmin_gender(gender);
		info.setAdmin_mobile(mobile);
		info.setAdmin_address(address);
		info.setAdmin_country(country);
		info.setAdmin_dob(dob);
		info.setAdmin_email(email);
	}
	
	public void getProfile(String name) throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("update admin set name=?,gender=?,mobile=?,address=?,country=?,dob=?,email=? where username='"+name+"' ");
			pst.setString(1, info.getAdmin_name());
			pst.setString(2, info.getAdmin_gender());
			pst.setString(3, info.getAdmin_mobile());
			pst.setString(4, info.getAdmin_address());
			pst.setString(5, info.getAdmin_country());
			pst.setString(6, info.getAdmin_dob());
			pst.setString(7, info.getAdmin_email());
			i=pst.executeUpdate();
			
	}
	
	public void forget(String name, String ques, String ans)
	{
		
		info.setAdmin_username(name);
		info.setAdmin_ques(ques);
		info.setAdmin_ans(ans);
		
	}
	
	public void forget_check() throws SQLException
	{
		conn.Connec();
		st=conn.con.createStatement();
		rst=st.executeQuery("select sec_ques,sec_ans from admin where username='"+info.getAdmin_username()+"' ");
			
	}
	
	public void forget(String name,String pass) throws SQLException
	{
		info.setAdmin_username(name);
		info.setAdmin_password(pass);
		
			
	}
	public void forget() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update admin set password=? where username='"+info.getAdmin_username()+"' ");
			pst.setString(1, info.getAdmin_password());
			
			i=pst.executeUpdate();
			
	}
	
	public void security(String name, String ques,String ans) throws SQLException
	{
		info.setAdmin_username(name);
		info.setAdmin_ques(ques);
		info.setAdmin_ans(ans);
		
	} 
	
	public void security() throws SQLException
	{
		conn.Connec(); 
		pst=conn.con.prepareStatement("update admin set sec_ques=?,sec_ans=? where username='"+info.getAdmin_username()+"' ");
			pst.setString(1, info.getAdmin_ques());
			pst.setString(2, info.getAdmin_ans());
			
			i=pst.executeUpdate();
			
	}
	
	public void setAdminacc(String name, String pass, String ques, String ans)
	{
		
		info.setAdmin_username(name);
		info.setAdmin_password(pass);
		info.setAdmin_ques(ques);
		info.setAdmin_ans(ans);
	}
	
	public void getAdminacc() throws SQLException
	{ 
		conn.Connec();
		pst=conn.con.prepareStatement("insert into admin (username,password,sec_ques,sec_ans) values(?,?,?,?)");
		pst.setString(1, info.getAdmin_username());
		pst.setString(2, info.getAdmin_password());
		pst.setString(3, info.getAdmin_ques());
		pst.setString(4, info.getAdmin_ans());
		i=pst.executeUpdate();
	}
	
	public void deleteAdmin(String username) throws SQLException
	{ 
		conn.Connec();
		pst=conn.con.prepareStatement("delete from admin where username='"+username+"' ");
		i=pst.executeUpdate();
	}
	
	
	public void setEmpacc(String name, String pass, String ques, String ans)
	{
		
		info.setEmp_uname(name);
		info.setEmp_pass(pass);
		info.setEmp_ques(ques);
		info.setEmp_ans(ans);
	}
	
	public void getEmpacc() throws SQLException
	{ 
		conn.Connec();
		pst=conn.con.prepareStatement("insert into emp (username,password,sec_ques,sec_ans) values(?,?,?,?)");
		pst.setString(1, info.getEmp_uname());
		pst.setString(2, info.getEmp_pass());
		pst.setString(3, info.getEmp_ques());
		pst.setString(4, info.getEmp_ans());
		i=pst.executeUpdate();
	}
	
	public void deleteEmp(String username) throws SQLException
	{ 
		conn.Connec();
		pst=conn.con.prepareStatement("delete from emp where username='"+username+"' ");
		i=pst.executeUpdate();
	}
}
