package com.controller;

import java.sql.*;

import com.view.Info;

public class Contact {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	PreparedStatement pst;
	public int i;
	public void setMail(String name, String email, String mobile, String message)
	{
		
		info.setName(name);
		info.setEmail(email);
		info.setMobile(mobile);
		info.setMessage(message);
	}
	
	public void getMail() throws SQLException
	{
		conn.Connec();
		pst=conn.con.prepareStatement("insert into mail (name,email,mobile,message)values(?,?,?,?)");
		
		pst.setString(1, info.getName());
		pst.setString(2, info.getEmail());
		pst.setString(3, info.getMobile());
		pst.setString(4, info.getMessage());
		
		i=pst.executeUpdate();
		
		
	}
}
