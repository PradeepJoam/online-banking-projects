package com.controller;

import com.view.Info;
import java.sql.*;

public class Menu_bar {
	Connectivity obj=new Connectivity();
	Info info=new Info();
	public PreparedStatement pst;
	public Statement st;
	public ResultSet rst;
	public int i;
	public void setMenu(String menuName, String menuPath, String subMenuName, String subMenuPath)
	{
		info.setMenuName(menuName);
		info.setMenuPath(menuPath);
		info.setSubMenuName(subMenuName);
		info.setSubMenuPath(subMenuPath);
		
	}
	
	public void getMenu() throws SQLException
	{
		obj.Connec();
		pst=obj.con.prepareStatement("insert into menu (menu,menupath,submenu,submenupath)values(?,?,?,?)");
		pst.setString(1, info.getMenuName());
		pst.setString(2, info.getMenuPath());
		pst.setString(3, info.getSubMenuName());
		pst.setString(4, info.getSubMenuPath());
		i=pst.executeUpdate();
	}
	
	public void checkMenu() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select * from menu where menu='"+info.getMenuName()+"' ");
	}
	
	public void setSubMenu(String subMenuName, String subMenuPath)
	{
	
		info.setSubMenuName(subMenuName);
		info.setSubMenuPath(subMenuPath);
		
	}
	
	public void updateSubMenu() throws SQLException
	{
		obj.Connec();
		pst=obj.con.prepareStatement("update menu set submenu=?,submenupath=? where menu='"+info.getMenuName()+"' ");
		pst.setString(1, info.getSubMenuName());
		pst.setString(2, info.getSubMenuPath());
		i=pst.executeUpdate();
	}
	
	public void getSubMenu() throws SQLException
	{
		obj.Connec();
		st=obj.con.createStatement();
		rst=st.executeQuery("select submenu,submenupath from menu where menu='"+info.getMenuName()+"' ");
	}
	
	public void delMenu(String MenuName)
	{
	
		info.setMenuName(MenuName);
		
		
	}
	
	public void delMenu(String MenuName, String subMenuName, String subMenuPath)
	{
	
		info.setMenuName(MenuName);
		info.setSubMenuName(subMenuName);
		info.setSubMenuPath(subMenuPath);
		
	}
	
	public void delMenu() throws SQLException
	{
		obj.Connec();
		pst=obj.con.prepareStatement("delete from menu where menu='"+info.getMenuName()+"' ");
		i=pst.executeUpdate();
	}
	
	public void delSubMenu() throws SQLException
	{
		obj.Connec();
		pst=obj.con.prepareStatement("update menu set submenu=?,submenupath=? where menu='"+info.getMenuName()+"' ");
		pst.setString(1, info.getSubMenuName());
		pst.setString(2, info.getSubMenuPath());
		i=pst.executeUpdate();
	}	
	
	

}
