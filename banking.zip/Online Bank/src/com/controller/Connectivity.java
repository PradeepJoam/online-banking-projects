package com.controller;

import java.sql.Connection;
import java.sql.DriverManager;
public class Connectivity {
	public Connection con;
	public void Connec()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_bank","root","");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}