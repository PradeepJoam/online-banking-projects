package com;

import java.io.*;
import java.sql.*;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.controller.Connectivity;


/**
 * Servlet implementation class Update_services
 */
@WebServlet("/Update_services")
public class Update_services extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update_services() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String UPLOAD_DIRECTORY1 = "D:/Eclipse/Online Bank/WebContent/images/";
        File f = new File(UPLOAD_DIRECTORY1 + "/" );
        f.mkdir();
        String UPLOAD_DIRECTORY = "D:/Eclipse/Online Bank/WebContent/images/";
        String title = null,data=null,linkname=null,linkpath=null,original_title=null;

        String attachment1 = null;

        if (ServletFileUpload.isMultipartContent(request)) 
        {
            try 
            {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                for (FileItem item : multiparts) 
                {
                    if (!item.isFormField()) 
                    {
                        if (item.getFieldName().equals("file")) 
                        {
                            attachment1 = new File(item.getName()).getName();
                            item.write(new File(UPLOAD_DIRECTORY + attachment1));
                        }
                    } 
                    else 
                    {

                    	if (item.getFieldName().equals("id")) 
                        {
                            original_title = item.getString();
                        }
                    	if (item.getFieldName().equals("title")) 
                        {
                            title = item.getString();
                        }
                        if (item.getFieldName().equals("data")) 
                        {
                            data = item.getString();
                        }
                        if (item.getFieldName().equals("linkname")) 
                        {
                            linkname = item.getString();
                        }
                        if (item.getFieldName().equals("linkpath")) 
                        { 
                            linkpath = item.getString();
                        }
                    }
                }
            } 
            catch (Exception ex) 
            {
                System.out.println("File Upload Failed due to " + ex);

            }
        } 
        else 
        {
        	System.out.println("Sorry this Servlet only handles file upload request");
        }

      
		    String path=UPLOAD_DIRECTORY + attachment1;
		    Connectivity obj=new Connectivity();
			obj.Connec();
			
			
			try 
			{
				PreparedStatement pst=obj.con.prepareStatement("update services set imgname=?,imgpath=?,title=?,data=?,linkname=?,link=? where title='"+original_title+"' ");
				pst.setString(1, attachment1);
				pst.setString(2, path);
				pst.setString(3, title);
				pst.setString(4, data);
				pst.setString(5, linkname);
				pst.setString(6, linkpath);
				int i=pst.executeUpdate();
				if(i>0)
				{ 
					out.print("<script>alert('Uploaded!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/editServices.jsp");
				}
				else
				{
					out.print("<script>alert('Failed!')</script>");
					response.setHeader("Refresh", "0.00001;url=admin/editServices.jsp");
				}
				
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
