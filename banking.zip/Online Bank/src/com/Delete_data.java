package com;

import java.sql.*;

import com.controller.Connectivity;
import com.view.Info;

public class Delete_data {
	Connectivity conn=new Connectivity();
	Info info=new Info();
	PreparedStatement pst;
	public int i;
	public void delTrading(String id)
	{
		
		info.setTrading_title(id);
	}
	
	public void delTrading() throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("delete from trading where title='"+info.getTrading_title()+"' ");
		
		
		i=pst.executeUpdate();
	
		
	}
	
	
	public void delServices(String id)
	{
		
		info.setServices_title(id);
	}
	
	public void delServices() throws SQLException
	{
		conn.Connec();
		
		pst=conn.con.prepareStatement("delete from services where title='"+info.getServices_title()+"' ");
		
		
		i=pst.executeUpdate();
	
		
	}

}
